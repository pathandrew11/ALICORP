/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Cliente;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    // Listar clientes
    public List<Cliente> listarClientes() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM clientes";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Cliente c = new Cliente();
                c.setIdCliente(rs.getInt("id_cliente"));
                c.setRucDni(rs.getString("ruc_dni"));
                c.setRazonSocial(rs.getString("razon_social"));
                c.setDireccion(rs.getString("direccion"));
                c.setTelefono(rs.getString("telefono"));
                c.setEmail(rs.getString("email"));
                lista.add(c);
            }
            con.close();
        } catch (Exception e) { e.printStackTrace(); }
        return lista;
    }

    // Registrar cliente
    public boolean registrarCliente(Cliente c) {
        String sql = "INSERT INTO clientes (ruc_dni, razon_social, direccion, telefono, email) VALUES (?, ?, ?, ?, ?)";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getRucDni());
            ps.setString(2, c.getRazonSocial());
            ps.setString(3, c.getDireccion());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getEmail());
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
    
    // Eliminar cliente
    public boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id_cliente = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
}