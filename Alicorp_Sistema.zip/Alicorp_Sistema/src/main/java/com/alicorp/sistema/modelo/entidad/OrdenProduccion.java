/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.entidad;

import java.sql.Timestamp;

public class OrdenProduccion {
    private int idOrdenProd;
    private int idProducto;
    private String nombreProducto;
    private int cantidad;
    private Timestamp fechaSolicitud;
    private String estado;

    public OrdenProduccion() {
    }

    // Getters y Setters
    public int getIdOrdenProd() { return idOrdenProd; }
    public void setIdOrdenProd(int idOrdenProd) { this.idOrdenProd = idOrdenProd; }

    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }

    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public Timestamp getFechaSolicitud() { return fechaSolicitud; }
    public void setFechaSolicitud(Timestamp fechaSolicitud) { this.fechaSolicitud = fechaSolicitud; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
