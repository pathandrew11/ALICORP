/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.OrdenProduccion;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProduccionDAO {

    // Registrar una nueva orden de producción (Estado: Pendiente)
    public boolean registrarOrden(int idProducto, int cantidad) {
        String sql = "INSERT INTO orden_produccion (id_producto, cantidad, estado) VALUES (?, ?, 'Pendiente')";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.setInt(2, cantidad);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar historial de producción
    public List<OrdenProduccion> listarOrdenes() {
        List<OrdenProduccion> lista = new ArrayList<>();
        String sql = "SELECT op.id_orden_prod, op.cantidad, op.fecha_solicitud, op.estado, p.nombre " +
                     "FROM orden_produccion op " +
                     "JOIN productos p ON op.id_producto = p.id_producto " +
                     "ORDER BY op.fecha_solicitud DESC";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                OrdenProduccion op = new OrdenProduccion();
                op.setIdOrdenProd(rs.getInt("id_orden_prod"));
                op.setNombreProducto(rs.getString("nombre"));
                op.setCantidad(rs.getInt("cantidad"));
                op.setFechaSolicitud(rs.getTimestamp("fecha_solicitud"));
                op.setEstado(rs.getString("estado"));
                lista.add(op);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Finalizar orden (Cambiar estado a 'Finalizado')
    public boolean finalizarOrden(int idOrden) {
        String sql = "UPDATE orden_produccion SET estado = 'Finalizado' WHERE id_orden_prod = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idOrden);
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Obtener datos de una orden específica (para saber cuánto sumar al stock)
    public OrdenProduccion obtenerOrden(int idOrden) {
        OrdenProduccion op = null;
        String sql = "SELECT * FROM orden_produccion WHERE id_orden_prod = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idOrden);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                op = new OrdenProduccion();
                op.setIdOrdenProd(rs.getInt("id_orden_prod"));
                op.setIdProducto(rs.getInt("id_producto"));
                op.setCantidad(rs.getInt("cantidad"));
                op.setEstado(rs.getString("estado"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return op;
    }
}
