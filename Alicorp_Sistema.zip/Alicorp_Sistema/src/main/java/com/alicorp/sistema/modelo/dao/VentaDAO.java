/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Venta;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    public boolean registrarVenta(int idProducto, int cantidad, double total) {
        String sql = "INSERT INTO ventas (id_producto, cantidad, precio_total) VALUES (?, ?, ?)";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.setInt(2, cantidad);
            ps.setDouble(3, total);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // NUEVO: Método para listar el historial de ventas
    public List<Venta> listarVentas() {
        List<Venta> lista = new ArrayList<>();
        // Hacemos JOIN para traer el nombre del producto en lugar de solo su ID
        String sql = "SELECT v.id_venta, v.cantidad, v.precio_total, v.fecha, p.nombre " +
                     "FROM ventas v " +
                     "JOIN productos p ON v.id_producto = p.id_producto " +
                     "ORDER BY v.fecha DESC";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Venta v = new Venta();
                v.setIdVenta(rs.getInt("id_venta"));
                v.setNombreProducto(rs.getString("nombre")); // Guardamos el nombre
                v.setCantidad(rs.getInt("cantidad"));
                v.setPrecioTotal(rs.getDouble("precio_total"));
                v.setFecha(rs.getTimestamp("fecha"));
                lista.add(v);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}