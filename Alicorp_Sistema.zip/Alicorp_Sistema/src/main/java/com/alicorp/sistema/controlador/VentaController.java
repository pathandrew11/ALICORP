/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.dao.VentaDAO;
import com.alicorp.sistema.modelo.entidad.Producto;
import com.alicorp.sistema.modelo.entidad.Venta;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "VentaController", urlPatterns = {"/VentaController"})
public class VentaController extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();
    private VentaDAO ventaDAO = new VentaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "nueva";

        switch (accion) {
            case "nueva":
                mostrarFormulario(request, response);
                break;
            case "historial":
                listarHistorial(request, response);
                break;
            default:
                mostrarFormulario(request, response);
        }
    }

    private void mostrarFormulario(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Producto> lista = productoDAO.listarProductos();
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("venta.jsp").forward(request, response);
    }

    private void listarHistorial(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Venta> historial = ventaDAO.listarVentas();
        request.setAttribute("ventas", historial);
        request.getRequestDispatcher("historialVentas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));
        
        double precio = productoDAO.obtenerPrecio(idProducto);
        double total = precio * cantidad;

        boolean stockActualizado = productoDAO.actualizarStock(idProducto, cantidad);

        if (stockActualizado) {
            ventaDAO.registrarVenta(idProducto, cantidad, total);
            request.setAttribute("mensaje", "¡Venta registrada con éxito! Total: S/. " + total);
        } else {
            request.setAttribute("error", "Error: Stock insuficiente para realizar la venta.");
        }

        // Recargamos el formulario
        mostrarFormulario(request, response);
    }
}