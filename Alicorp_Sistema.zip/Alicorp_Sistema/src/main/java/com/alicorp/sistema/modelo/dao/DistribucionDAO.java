/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.OrdenDistribucion;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DistribucionDAO {

    // Listar todas las rutas
    public List<OrdenDistribucion> listarRutas() {
        List<OrdenDistribucion> lista = new ArrayList<>();
        String sql = "SELECT * FROM orden_distribucion ORDER BY fecha_entrega DESC";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrdenDistribucion orden = new OrdenDistribucion();
                orden.setIdOrden(rs.getInt("id_orden"));
                orden.setDestinatario(rs.getString("destinatario"));
                orden.setDireccion(rs.getString("direccion"));
                orden.setRuta(rs.getString("ruta"));
                orden.setTransportista(rs.getString("transportista"));
                orden.setFechaEntrega(rs.getDate("fecha_entrega"));
                orden.setEstado(rs.getString("estado"));
                lista.add(orden);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Registrar nueva ruta
    public boolean registrarRuta(OrdenDistribucion orden) {
        String sql = "INSERT INTO orden_distribucion (destinatario, direccion, ruta, transportista, fecha_entrega, estado) VALUES (?, ?, ?, ?, ?, 'Pendiente')";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, orden.getDestinatario());
            ps.setString(2, orden.getDireccion());
            ps.setString(3, orden.getRuta());
            ps.setString(4, orden.getTransportista());
            ps.setDate(5, orden.getFechaEntrega());
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // NUEVO: Método para actualizar el estado de un envío
    public boolean actualizarEstado(int idOrden, String nuevoEstado) {
        String sql = "UPDATE orden_distribucion SET estado = ? WHERE id_orden = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nuevoEstado);
            ps.setInt(2, idOrden);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
