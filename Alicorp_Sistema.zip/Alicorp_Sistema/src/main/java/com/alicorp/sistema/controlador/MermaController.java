/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.MermaDAO;
import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.entidad.Merma;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "MermaController", urlPatterns = {"/MermaController"})
public class MermaController extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();
    private MermaDAO mermaDAO = new MermaDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "nueva";

        switch (accion) {
            case "nueva":
                mostrarFormulario(request, response);
                break;
            case "historial":
                listarHistorial(request, response);
                break;
            default:
                mostrarFormulario(request, response);
        }
    }

    private void mostrarFormulario(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Producto> lista = productoDAO.listarProductos();
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("registroMermas.jsp").forward(request, response);
    }

    private void listarHistorial(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Merma> historial = mermaDAO.listarMermas();
        request.setAttribute("mermas", historial);
        request.getRequestDispatcher("historialMermas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));
        String motivo = request.getParameter("motivo");

        // 1. Descontar Stock (Igual que una venta, porque el producto sale)
        boolean stockActualizado = productoDAO.actualizarStock(idProducto, cantidad);

        if (stockActualizado) {
            // 2. Registrar la merma
            mermaDAO.registrarMerma(idProducto, cantidad, motivo);
            request.setAttribute("mensaje", "Merma registrada correctamente. Stock descontado.");
        } else {
            request.setAttribute("error", "Error: Stock insuficiente para registrar esta merma.");
        }

        // Recargar formulario
        mostrarFormulario(request, response);
    }
}
