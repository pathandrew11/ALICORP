/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.OrdenCompra;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrdenCompraDAO {

    public boolean registrarOrden(OrdenCompra orden) {
        String sql = "INSERT INTO orden_compra (id_proveedor, id_producto, cantidad, precio_unitario, monto_total) VALUES (?, ?, ?, ?, ?)";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, orden.getIdProveedor());
            ps.setInt(2, orden.getIdProducto());
            ps.setInt(3, orden.getCantidad());
            ps.setDouble(4, orden.getPrecioUnitario());
            ps.setDouble(5, orden.getMontoTotal());
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<OrdenCompra> listarOrdenes() {
        List<OrdenCompra> lista = new ArrayList<>();
        String sql = "SELECT oc.*, pv.razon_social, pd.nombre " +
                     "FROM orden_compra oc " +
                     "JOIN proveedores pv ON oc.id_proveedor = pv.id_proveedor " +
                     "JOIN productos pd ON oc.id_producto = pd.id_producto " +
                     "ORDER BY oc.fecha_emision DESC";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrdenCompra oc = new OrdenCompra();
                oc.setIdOrdenCompra(rs.getInt("id_orden_compra"));
                oc.setNombreProveedor(rs.getString("razon_social"));
                oc.setNombreProducto(rs.getString("nombre"));
                oc.setIdProducto(rs.getInt("id_producto")); // Importante para actualizar stock
                oc.setCantidad(rs.getInt("cantidad"));
                oc.setPrecioUnitario(rs.getDouble("precio_unitario"));
                oc.setMontoTotal(rs.getDouble("monto_total"));
                oc.setFechaEmision(rs.getTimestamp("fecha_emision"));
                oc.setEstado(rs.getString("estado"));
                lista.add(oc);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Cambiar estado a 'Recibido'
    public boolean recepcionarOrden(int idOrden) {
        String sql = "UPDATE orden_compra SET estado = 'Recibido' WHERE id_orden_compra = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idOrden);
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Obtener una orden para procesar el stock
    public OrdenCompra obtenerOrden(int idOrden) {
        OrdenCompra oc = null;
        String sql = "SELECT * FROM orden_compra WHERE id_orden_compra = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idOrden);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                oc = new OrdenCompra();
                oc.setIdOrdenCompra(rs.getInt("id_orden_compra"));
                oc.setIdProducto(rs.getInt("id_producto"));
                oc.setCantidad(rs.getInt("cantidad"));
                oc.setEstado(rs.getString("estado"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return oc;
    }
}
