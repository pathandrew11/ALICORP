/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Merma;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MermaDAO {

    // Registrar una nueva merma
    public boolean registrarMerma(int idProducto, int cantidad, String motivo) {
        String sql = "INSERT INTO mermas (id_producto, cantidad, motivo) VALUES (?, ?, ?)";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.setInt(2, cantidad);
            ps.setString(3, motivo);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar historial de mermas
    public List<Merma> listarMermas() {
        List<Merma> lista = new ArrayList<>();
        String sql = "SELECT m.id_merma, m.cantidad, m.motivo, m.fecha, p.nombre " +
                     "FROM mermas m " +
                     "JOIN productos p ON m.id_producto = p.id_producto " +
                     "ORDER BY m.fecha DESC";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Merma m = new Merma();
                m.setIdMerma(rs.getInt("id_merma"));
                m.setNombreProducto(rs.getString("nombre"));
                m.setCantidad(rs.getInt("cantidad"));
                m.setMotivo(rs.getString("motivo"));
                m.setFecha(rs.getTimestamp("fecha"));
                lista.add(m);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}
