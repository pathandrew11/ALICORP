/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ClienteDAO;
import com.alicorp.sistema.modelo.entidad.Cliente;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ClienteController", urlPatterns = {"/ClienteController"})
public class ClienteController extends HttpServlet {

    private ClienteDAO clienteDAO = new ClienteDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listar(request, response);
                break;
            case "eliminar":
                eliminar(request, response);
                break;
            default:
                listar(request, response);
        }
    }

    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Cliente> lista = clienteDAO.listarClientes();
        request.setAttribute("clientes", lista);
        request.getRequestDispatcher("clientes.jsp").forward(request, response);
    }

    private void eliminar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        if(clienteDAO.eliminarCliente(id)) {
            request.setAttribute("mensaje", "Cliente eliminado correctamente.");
        } else {
            request.setAttribute("error", "No se puede eliminar (tiene ventas asociadas).");
        }
        listar(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Cliente c = new Cliente();
            c.setRucDni(request.getParameter("rucDni"));
            c.setRazonSocial(request.getParameter("razonSocial"));
            c.setDireccion(request.getParameter("direccion"));
            c.setTelefono(request.getParameter("telefono"));
            c.setEmail(request.getParameter("email"));
            
            if(clienteDAO.registrarCliente(c)) {
                request.setAttribute("mensaje", "Cliente registrado con éxito.");
            } else {
                request.setAttribute("error", "Error al registrar (posible duplicado).");
            }
        } catch (Exception e) {
            request.setAttribute("error", "Datos inválidos.");
        }
        listar(request, response);
    }
}
