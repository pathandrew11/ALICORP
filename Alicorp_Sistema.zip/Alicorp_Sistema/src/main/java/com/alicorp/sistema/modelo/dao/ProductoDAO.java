/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Producto;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    // Listar todos los productos
    public List<Producto> listarProductos() {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setCategoria(rs.getString("categoria"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
                lista.add(p);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Buscar productos por nombre
    public List<Producto> buscarPorNombre(String texto) {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM productos WHERE nombre LIKE ?";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + texto + "%");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setCategoria(rs.getString("categoria"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
                lista.add(p);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Registrar un producto nuevo Y su movimiento inicial (Ajuste)
    public boolean registrarProducto(Producto p) {
        String sqlProd = "INSERT INTO productos (nombre, categoria, precio, stock) VALUES (?, ?, ?, ?)";
        String sqlAjuste = "INSERT INTO ajustes_inventario (id_producto, cantidad, motivo) VALUES (?, ?, 'Inventario Inicial')";
        
        Connection con = null;
        PreparedStatement psProd = null;
        PreparedStatement psAjuste = null;
        ResultSet rs = null;
        
        try {
            con = Conexion.getConexion();
            // Desactivamos el auto-commit para manejar la transacción
            con.setAutoCommit(false);
            
            // 1. Insertar Producto y obtener ID generado
            psProd = con.prepareStatement(sqlProd, Statement.RETURN_GENERATED_KEYS);
            psProd.setString(1, p.getNombre());
            psProd.setString(2, p.getCategoria());
            psProd.setDouble(3, p.getPrecio());
            psProd.setInt(4, p.getStock());
            int filasAfectadas = psProd.executeUpdate();
            
            if (filasAfectadas == 0) {
                throw new Exception("No se pudo guardar el producto.");
            }

            // 2. Obtener el ID del producto recién creado
            rs = psProd.getGeneratedKeys();
            int idProductoGenerado = 0;
            if (rs.next()) {
                idProductoGenerado = rs.getInt(1);
            }
            
            // 3. Si hay stock inicial (>0), registramos el movimiento en ajustes
            if (idProductoGenerado > 0 && p.getStock() > 0) {
                psAjuste = con.prepareStatement(sqlAjuste);
                psAjuste.setInt(1, idProductoGenerado);
                psAjuste.setInt(2, p.getStock());
                psAjuste.executeUpdate();
            }
            
            // Confirmar transacción
            con.commit();
            return true;
            
        } catch (Exception e) {
            e.printStackTrace();
            try {
                if (con != null) con.rollback(); // Deshacer cambios si falla
            } catch (Exception ex) { ex.printStackTrace(); }
            return false;
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (psProd != null) psProd.close(); } catch (Exception e) {}
            try { if (psAjuste != null) psAjuste.close(); } catch (Exception e) {}
            try { if (con != null) con.close(); } catch (Exception e) {}
        }
    }

    // Actualizar stock (Venta - RESTA)
    public boolean actualizarStock(int idProducto, int cantidadVendida) {
        String sql = "UPDATE productos SET stock = stock - ? WHERE id_producto = ? AND stock >= ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, cantidadVendida);
            ps.setInt(2, idProducto);
            ps.setInt(3, cantidadVendida);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Reponer stock (Devolución/Producción - SUMA)
    public boolean reponerStock(int idProducto, int cantidad) {
        String sql = "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, cantidad);
            ps.setInt(2, idProducto);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Obtener precio de un producto
    public double obtenerPrecio(int idProducto) {
        double precio = 0;
        String sql = "SELECT precio FROM productos WHERE id_producto = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                precio = rs.getDouble("precio");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
        return precio;
    }

    // Obtener producto por ID (Para cargar sus datos al editar)
    public Producto obtenerPorId(int id) {
        Producto p = null;
        String sql = "SELECT * FROM productos WHERE id_producto = ?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                p = new Producto();
                p.setIdProducto(rs.getInt("id_producto"));
                p.setNombre(rs.getString("nombre"));
                p.setCategoria(rs.getString("categoria"));
                p.setPrecio(rs.getDouble("precio"));
                p.setStock(rs.getInt("stock"));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p;
    }

    // Actualizar producto existente
    public boolean actualizarProducto(Producto p) {
        String sql = "UPDATE productos SET nombre=?, categoria=?, precio=?, stock=? WHERE id_producto=?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getStock());
            ps.setInt(5, p.getIdProducto());
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Eliminar producto
    public boolean eliminarProducto(int id) {
        String sql = "DELETE FROM productos WHERE id_producto=?";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
