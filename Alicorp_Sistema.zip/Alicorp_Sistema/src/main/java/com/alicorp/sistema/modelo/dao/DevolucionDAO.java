/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Devolucion;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DevolucionDAO {

    public boolean registrarDevolucion(int idProducto, int cantidad, String motivo) {
        String sql = "INSERT INTO devoluciones (id_producto, cantidad, motivo) VALUES (?, ?, ?)";
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idProducto);
            ps.setInt(2, cantidad);
            ps.setString(3, motivo);
            
            int filas = ps.executeUpdate();
            con.close();
            return filas > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar historial de devoluciones
    public List<Devolucion> listarDevoluciones() {
        List<Devolucion> lista = new ArrayList<>();
        String sql = "SELECT d.id_devolucion, d.cantidad, d.motivo, d.fecha, p.nombre " +
                     "FROM devoluciones d " +
                     "JOIN productos p ON d.id_producto = p.id_producto " +
                     "ORDER BY d.fecha DESC";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Devolucion d = new Devolucion();
                d.setIdDevolucion(rs.getInt("id_devolucion"));
                d.setNombreProducto(rs.getString("nombre"));
                d.setCantidad(rs.getInt("cantidad"));
                d.setMotivo(rs.getString("motivo"));
                d.setFecha(rs.getTimestamp("fecha"));
                lista.add(d);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}
