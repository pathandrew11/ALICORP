/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.entidad;

import java.sql.Timestamp;

public class Movimiento {
    private String tipo;        // "Venta", "Compra", "Producción", etc.
    private Timestamp fecha;
    private int cantidad;
    private String detalle;     // Ej: "Cliente: Juan" o "Motivo: Dañado"
    private int entrada;        // Valor positivo o 0
    private int salida;         // Valor positivo o 0
    
    public Movimiento() {}

    // Getters y Setters
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public Timestamp getFecha() { return fecha; }
    public void setFecha(Timestamp fecha) { this.fecha = fecha; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public String getDetalle() { return detalle; }
    public void setDetalle(String detalle) { this.detalle = detalle; }
    public int getEntrada() { return entrada; }
    public void setEntrada(int entrada) { this.entrada = entrada; }
    public int getSalida() { return salida; }
    public void setSalida(int salida) { this.salida = salida; }
}