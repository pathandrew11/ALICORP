/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.DevolucionDAO;
import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.entidad.Devolucion;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DevolucionController", urlPatterns = {"/DevolucionController"})
public class DevolucionController extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();
    private DevolucionDAO devolucionDAO = new DevolucionDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "nueva";

        switch (accion) {
            case "nueva":
                mostrarFormulario(request, response);
                break;
            case "historial":
                listarHistorial(request, response);
                break;
            default:
                mostrarFormulario(request, response);
        }
    }

    private void mostrarFormulario(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Producto> lista = productoDAO.listarProductos();
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("registrarDevolucion.jsp").forward(request, response);
    }

    private void listarHistorial(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Devolucion> historial = devolucionDAO.listarDevoluciones();
        request.setAttribute("devoluciones", historial);
        request.getRequestDispatcher("historialDevoluciones.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));
        String motivo = request.getParameter("motivo");

        // 1. Reponer Stock
        boolean stockRepuesto = productoDAO.reponerStock(idProducto, cantidad);

        if (stockRepuesto) {
            // 2. Registrar la devolución
            devolucionDAO.registrarDevolucion(idProducto, cantidad, motivo);
            request.setAttribute("mensaje", "Devolución registrada correctamente. Stock actualizado.");
        } else {
            request.setAttribute("error", "Error al actualizar el stock.");
        }

        // Recargar formulario
        mostrarFormulario(request, response);
    }
}