/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Venta;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ComprobanteDAO {

    // Buscar una venta específica por su ID para generar el comprobante
    public Venta obtenerDatosComprobante(int idVenta) {
        Venta venta = null;
        String sql = "SELECT v.id_venta, v.cantidad, v.precio_total, v.fecha, p.nombre, p.precio " +
                     "FROM ventas v " +
                     "JOIN productos p ON v.id_producto = p.id_producto " +
                     "WHERE v.id_venta = ?";
        
        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idVenta);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                venta = new Venta();
                venta.setIdVenta(rs.getInt("id_venta"));
                venta.setNombreProducto(rs.getString("nombre"));
                venta.setCantidad(rs.getInt("cantidad"));
                venta.setPrecioTotal(rs.getDouble("precio_total"));
                venta.setFecha(rs.getTimestamp("fecha"));
                // Usamos un campo auxiliar o el mismo objeto si tiene setters
                // Para este ejemplo básico, el precio unitario se puede calcular o traer
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return venta;
    }
}