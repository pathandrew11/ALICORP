/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.UserDAO;
import com.alicorp.sistema.modelo.entidad.Usuario;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UsuarioController", urlPatterns = {"/UsuarioController"})
public class UsuarioController extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listarUsuarios(request, response);
                break;
            default:
                listarUsuarios(request, response);
        }
    }

    private void listarUsuarios(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Usuario> lista = userDAO.listarUsuarios();
        request.setAttribute("usuarios", lista);
        request.getRequestDispatcher("usuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            String nombre = request.getParameter("nombre");
            String rol = request.getParameter("rol");
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            Usuario u = new Usuario();
            u.setNombre(nombre);
            u.setRol(rol);
            u.setUsername(username);
            u.setPassword(password);

            boolean registrado = userDAO.registrarUsuario(u);

            if (registrado) {
                request.setAttribute("mensaje", "Usuario registrado correctamente.");
            } else {
                request.setAttribute("error", "Error: El usuario ya existe o datos inválidos.");
            }

        } catch (Exception e) {
            request.setAttribute("error", "Error: " + e.getMessage());
        }

        // Recargar lista
        listarUsuarios(request, response);
    }
}