/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ReporteDAO;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ReporteController", urlPatterns = {"/ReporteController"})
public class ReporteController extends HttpServlet {

    private ReporteDAO reporteDAO = new ReporteDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Obtener Alertas de Stock
        List<Producto> criticos = reporteDAO.obtenerStockCritico();
        
        // 2. Obtener KPIs (Indicadores Clave)
        double totalVentas = reporteDAO.obtenerTotalVentas();
        int totalMermas = reporteDAO.contarMermas();
        
        // 3. Enviar datos a la vista
        request.setAttribute("productosCriticos", criticos);
        request.setAttribute("totalVentas", totalVentas);
        request.setAttribute("totalMermas", totalMermas);
        
        request.getRequestDispatcher("reportes.jsp").forward(request, response);
    }
}
