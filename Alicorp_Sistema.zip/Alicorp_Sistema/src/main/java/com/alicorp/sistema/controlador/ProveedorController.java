/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ProveedorDAO;
import com.alicorp.sistema.modelo.entidad.Proveedor;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ProveedorController", urlPatterns = {"/ProveedorController"})
public class ProveedorController extends HttpServlet {

    private ProveedorDAO proveedorDAO = new ProveedorDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listar(request, response);
                break;
            default:
                listar(request, response);
        }
    }

    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Proveedor> lista = proveedorDAO.listarProveedores();
        request.setAttribute("proveedores", lista);
        request.getRequestDispatcher("proveedores.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            Proveedor p = new Proveedor();
            p.setRuc(request.getParameter("ruc"));
            p.setRazonSocial(request.getParameter("razonSocial"));
            p.setTelefono(request.getParameter("telefono"));
            p.setEmail(request.getParameter("email"));
            
            if(proveedorDAO.registrarProveedor(p)) {
                request.setAttribute("mensaje", "Proveedor registrado con éxito.");
            } else {
                request.setAttribute("error", "Error al registrar proveedor.");
            }
        } catch (Exception e) {
            request.setAttribute("error", "Datos inválidos.");
        }
        listar(request, response);
    }
}
