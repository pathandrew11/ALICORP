/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.DistribucionDAO;
import com.alicorp.sistema.modelo.entidad.OrdenDistribucion;
import java.io.IOException;
import java.sql.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "DistribucionController", urlPatterns = {"/DistribucionController"})
public class DistribucionController extends HttpServlet {

    private DistribucionDAO dao = new DistribucionDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listarRutas(request, response);
                break;
            case "actualizar": // Nueva acción para cambiar estado
                actualizarEstado(request, response);
                break;
            default:
                listarRutas(request, response);
        }
    }

    private void listarRutas(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<OrdenDistribucion> lista = dao.listarRutas();
        request.setAttribute("rutas", lista);
        request.getRequestDispatcher("rutas.jsp").forward(request, response);
    }

    private void actualizarEstado(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int idOrden = Integer.parseInt(request.getParameter("id"));
            String nuevoEstado = request.getParameter("estado");
            
            dao.actualizarEstado(idOrden, nuevoEstado);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        
        // Recargar la lista para ver el cambio
        listarRutas(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Recibir datos del formulario
        try {
            String destinatario = request.getParameter("destinatario");
            String direccion = request.getParameter("direccion");
            String ruta = request.getParameter("ruta");
            String transportista = request.getParameter("transportista");
            String fechaStr = request.getParameter("fecha");

            OrdenDistribucion orden = new OrdenDistribucion();
            orden.setDestinatario(destinatario);
            orden.setDireccion(direccion);
            orden.setRuta(ruta);
            orden.setTransportista(transportista);
            orden.setFechaEntrega(Date.valueOf(fechaStr));

            // Guardar
            dao.registrarRuta(orden);
            
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Recargar la página
        doGet(request, response);
    }
}
