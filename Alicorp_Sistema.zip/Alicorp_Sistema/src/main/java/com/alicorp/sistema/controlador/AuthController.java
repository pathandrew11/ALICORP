/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.UserDAO;
import com.alicorp.sistema.modelo.entidad.Usuario;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AuthController", urlPatterns = {"/AuthController"})
public class AuthController extends HttpServlet {

    private UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Recibir datos del formulario
        String user = request.getParameter("username");
        String pass = request.getParameter("password");

        // 2. Preguntar al DAO si el usuario existe
        Usuario usuario = userDAO.validarUsuario(user, pass);

        if (usuario != null) {
            // 3. ¡Éxito! Crear una sesión para recordar al usuario
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogueado", usuario);
            
            // 4. Mandarlo a la pantalla principal
            response.sendRedirect("dashboard.jsp");
        } else {
            // 5. Fallo: Mandarlo de vuelta al login con un mensaje
            request.setAttribute("error", "Usuario o contraseña incorrectos");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
    
    // Método para cerrar sesión (logout)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate(); // Destruir sesión
        response.sendRedirect("login.jsp");
    }
}