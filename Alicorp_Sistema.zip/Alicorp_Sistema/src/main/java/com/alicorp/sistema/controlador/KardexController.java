/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.KardexDAO;
import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.entidad.Movimiento;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "KardexController", urlPatterns = {"/KardexController"})
public class KardexController extends HttpServlet {

    private KardexDAO kardexDAO = new KardexDAO();
    private ProductoDAO productoDAO = new ProductoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // 1. Obtener ID del producto seleccionado
            int idProducto = Integer.parseInt(request.getParameter("id"));
            
            // 2. Obtener datos del producto (para mostrar nombre y stock actual)
            Producto p = productoDAO.obtenerPorId(idProducto);
            
            // 3. Obtener lista de movimientos
            List<Movimiento> movimientos = kardexDAO.obtenerKardexProducto(idProducto);
            
            // 4. Enviar a la vista
            request.setAttribute("producto", p);
            request.setAttribute("movimientos", movimientos);
            
            request.getRequestDispatcher("kardex.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ProductoController?accion=listar");
        }
    }
}
