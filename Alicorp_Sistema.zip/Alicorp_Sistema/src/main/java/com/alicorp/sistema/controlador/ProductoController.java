/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ProductoController", urlPatterns = {"/ProductoController"})
public class ProductoController extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listar(request, response);
                break;
            case "buscar":
                buscar(request, response);
                break;
            case "nuevo":
                request.getRequestDispatcher("registrarProducto.jsp").forward(request, response);
                break;
            case "editar":
                editar(request, response);
                break;
            case "eliminar":
                eliminar(request, response);
                break;
            default:
                listar(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion"); // Para distinguir entre guardar nuevo o actualizar
        
        try {
            String nombre = request.getParameter("nombre");
            String categoria = request.getParameter("categoria");
            double precio = Double.parseDouble(request.getParameter("precio"));
            int stock = Integer.parseInt(request.getParameter("stock"));
            
            Producto p = new Producto();
            p.setNombre(nombre);
            p.setCategoria(categoria);
            p.setPrecio(precio);
            p.setStock(stock);
            
            boolean resultado = false;

            if ("actualizar".equals(accion)) {
                // Es una edición
                int id = Integer.parseInt(request.getParameter("idProducto"));
                p.setIdProducto(id);
                resultado = productoDAO.actualizarProducto(p);
                if (resultado) request.setAttribute("mensaje", "Producto actualizado correctamente.");
                else request.setAttribute("error", "Error al actualizar.");
            
            } else {
                // Es un registro nuevo
                resultado = productoDAO.registrarProducto(p);
                if (resultado) request.setAttribute("mensaje", "Producto registrado correctamente.");
                else request.setAttribute("error", "Error al registrar.");
            }
            
        } catch (Exception e) {
            request.setAttribute("error", "Error en los datos: " + e.getMessage());
        }
        
        listar(request, response);
    }

    private void listar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<Producto> lista = productoDAO.listarProductos();
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("verificarProducto.jsp").forward(request, response);
    }
    
    private void buscar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String texto = request.getParameter("nombre");
        List<Producto> lista = productoDAO.buscarPorNombre(texto);
        request.setAttribute("productos", lista);
        request.getRequestDispatcher("verificarProducto.jsp").forward(request, response);
    }

    private void editar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Producto p = productoDAO.obtenerPorId(id);
        request.setAttribute("producto", p);
        request.getRequestDispatcher("editarProducto.jsp").forward(request, response);
    }

    private void eliminar(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        if(productoDAO.eliminarProducto(id)) {
            request.setAttribute("mensaje", "Producto eliminado del catálogo.");
        } else {
            request.setAttribute("error", "No se puede eliminar (probablemente tiene ventas asociadas).");
        }
        listar(request, response);
    }
}