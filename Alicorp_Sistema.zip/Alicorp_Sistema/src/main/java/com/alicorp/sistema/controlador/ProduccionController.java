/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ProduccionDAO;
import com.alicorp.sistema.modelo.dao.ProductoDAO;
import com.alicorp.sistema.modelo.entidad.OrdenProduccion;
import com.alicorp.sistema.modelo.entidad.Producto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ProduccionController", urlPatterns = {"/ProduccionController"})
public class ProduccionController extends HttpServlet {

    private ProductoDAO productoDAO = new ProductoDAO();
    private ProduccionDAO produccionDAO = new ProduccionDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accion = request.getParameter("accion");
        if (accion == null) accion = "listar";

        switch (accion) {
            case "listar":
                listarProduccion(request, response);
                break;
            case "finalizar":
                finalizarOrden(request, response);
                break;
            default:
                listarProduccion(request, response);
        }
    }

    private void listarProduccion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Cargar productos para el formulario
        List<Producto> productos = productoDAO.listarProductos();
        request.setAttribute("productos", productos);
        
        // Cargar historial de órdenes
        List<OrdenProduccion> ordenes = produccionDAO.listarOrdenes();
        request.setAttribute("ordenes", ordenes);
        
        request.getRequestDispatcher("gestionProduccion.jsp").forward(request, response);
    }

    private void finalizarOrden(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int idOrden = Integer.parseInt(request.getParameter("id"));
        
        // 1. Obtener la orden para saber qué producto y cuánto sumar
        OrdenProduccion orden = produccionDAO.obtenerOrden(idOrden);
        
        if (orden != null && !"Finalizado".equals(orden.getEstado())) {
            // 2. Sumar al Stock (Usamos reponerStock que ya creamos para devoluciones, sirve igual)
            boolean stockActualizado = productoDAO.reponerStock(orden.getIdProducto(), orden.getCantidad());
            
            if (stockActualizado) {
                // 3. Marcar orden como finalizada
                produccionDAO.finalizarOrden(idOrden);
                request.setAttribute("mensaje", "Orden #" + idOrden + " finalizada. Stock actualizado.");
            } else {
                request.setAttribute("error", "Error al actualizar el stock.");
            }
        }
        
        // Recargar lista
        listarProduccion(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Registrar nueva orden
        int idProducto = Integer.parseInt(request.getParameter("idProducto"));
        int cantidad = Integer.parseInt(request.getParameter("cantidad"));

        boolean registrado = produccionDAO.registrarOrden(idProducto, cantidad);

        if (registrado) {
            request.setAttribute("mensaje", "Orden de producción solicitada correctamente.");
        } else {
            request.setAttribute("error", "Error al registrar la orden.");
        }

        // Recargar la página
        listarProduccion(request, response);
    }
}
