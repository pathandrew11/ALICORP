/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.controlador;

import com.alicorp.sistema.modelo.dao.ComprobanteDAO;
import com.alicorp.sistema.modelo.entidad.Venta;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ComprobanteController", urlPatterns = {"/ComprobanteController"})
public class ComprobanteController extends HttpServlet {

    private ComprobanteDAO comprobanteDAO = new ComprobanteDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
            // 1. Recibir el ID de la venta
            int idVenta = Integer.parseInt(request.getParameter("id"));
            
            // 2. Obtener los datos
            Venta datosVenta = comprobanteDAO.obtenerDatosComprobante(idVenta);
            
            if (datosVenta != null) {
                // 3. Enviar a la vista de impresión
                request.setAttribute("venta", datosVenta);
                request.getRequestDispatcher("comprobante.jsp").forward(request, response);
            } else {
                // Si no existe, volver al historial
                response.sendRedirect("VentaController?accion=historial");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp");
        }
    }
}