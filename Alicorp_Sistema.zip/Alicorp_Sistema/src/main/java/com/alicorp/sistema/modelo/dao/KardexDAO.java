/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.alicorp.sistema.modelo.dao;

import com.alicorp.sistema.modelo.entidad.Movimiento;
import com.alicorp.sistema.modelo.util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KardexDAO {

    public List<Movimiento> obtenerKardexProducto(int idProducto) {
        List<Movimiento> lista = new ArrayList<>();
        
        String sql = 
            // 1. Ventas (Salidas)
            "SELECT 'Salida' as operacion, 'Venta' as tipo, fecha, cantidad, CONCAT('Venta Nro ', id_venta) as detalle FROM ventas WHERE id_producto = ? " +
            "UNION ALL " +
            
            // 2. Compras (Entradas) - Solo las recibidas
            "SELECT 'Entrada', 'Compra', fecha_emision, cantidad, CONCAT('Prov: ', (SELECT razon_social FROM proveedores WHERE id_proveedor = orden_compra.id_proveedor)) FROM orden_compra WHERE id_producto = ? AND estado = 'Recibido' " +
            "UNION ALL " +
            
            // 3. Producción (Entradas) - Solo las finalizadas
            "SELECT 'Entrada', 'Produccion', fecha_solicitud, cantidad, CONCAT('Orden Fab. Nro ', id_orden_prod) FROM orden_produccion WHERE id_producto = ? AND estado = 'Finalizado' " +
            "UNION ALL " +
            
            // 4. Devoluciones (Entradas)
            "SELECT 'Entrada', 'Devolucion', fecha, cantidad, motivo FROM devoluciones WHERE id_producto = ? " +
            "UNION ALL " +
            
            // 5. Mermas (Salidas)
            "SELECT 'Salida', 'Merma', fecha, cantidad, motivo FROM mermas WHERE id_producto = ? " +
            "UNION ALL " +
            
            // 6. AJUSTES (Inventario Inicial)
            "SELECT 'Entrada', 'Ajuste', fecha, cantidad, motivo FROM ajustes_inventario WHERE id_producto = ? " +
            
            // Ordenar por fecha
            "ORDER BY 3 DESC";

        try {
            Connection con = Conexion.getConexion();
            PreparedStatement ps = con.prepareStatement(sql);
            
            // Asignar el ID producto a los 6 signos de interrogación (?)
            for(int i=1; i<=6; i++) {
                ps.setInt(i, idProducto);
            }
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Movimiento m = new Movimiento();
                String operacion = rs.getString("operacion");
                m.setTipo(rs.getString("tipo"));
                m.setFecha(rs.getTimestamp("fecha"));
                m.setCantidad(rs.getInt("cantidad"));
                m.setDetalle(rs.getString("detalle"));
                
                if ("Entrada".equals(operacion)) {
                    m.setEntrada(m.getCantidad());
                    m.setSalida(0);
                } else {
                    m.setEntrada(0);
                    m.setSalida(m.getCantidad());
                }
                
                lista.add(m);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
}